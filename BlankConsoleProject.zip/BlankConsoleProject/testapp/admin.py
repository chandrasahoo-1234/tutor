from django.contrib import admin
from .models import Tutor
# Register your models here.
class TutorAdmin(admin.ModelAdmin):
	list_display=['first_name','last_name','phone','email','password']
admin.site.register(Tutor,TutorAdmin)
