from testapp.models import Tutor
from django.shortcuts import render, redirect
from django.contrib.auth.hashers import make_password
from django.views import View
# Create your views here.
def index(request):
	return render(request,'testapp/index.html')
def login1(request):
	return render(request,'testapp/login.html')
def find(request):
	return render(request,'testapp/page.html')
def assignment(request):
	return render(request,'testapp/assignment.html')
def become(request):
	return render(request,'testapp/blog.html')
class Signup(View):
    def get(self, request):
        return render(request, 'testapp/ssignup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('firstname')
        last_name = postData.get('lastname')
        phone = postData.get('phone')
        email = postData.get('email')
        password = postData.get('password')
        # validation
        value = {
            'first_name': first_name,
            'last_name': last_name,
            'phone': phone,
            'email': email
        }
        error_message = None

        tutor = Tutor(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)
        error_message = self.validateTutor(tutor)

        if not error_message:
            print(first_name, last_name, phone, email, password)
            tutor.password = make_password(tutor.password)
            tutor.register()
            return redirect('/')
        else:
            data = {
                'error': error_message,
                'values': value
            }
            return render(request, 'testapp/ssignup.html', data)

    def validateTutor(self, tutor):
        error_message = None;
        if (not tutor.first_name):
            error_message = "First Name Required !!"
        elif len(tutor.first_name) < 4:
            error_message = 'First Name must be 4 char long or more'
        elif not tutor.last_name:
            error_message = 'Last Name Required'
        elif len(tutor.last_name) < 4:
            error_message = 'Last Name must be 4 char long or more'
        elif not tutor.phone:
            error_message = 'Phone Number required'
        elif len(tutor.phone) < 10:
            error_message = 'Phone Number must be 10 char Long'
        elif len(tutor.password) < 6:
            error_message = 'Password must be 6 char long'
        elif len(tutor.email) < 5:
            error_message = 'Email must be 5 char long'
        elif tutor.isExists():
            error_message = 'Email Address Already Registered..'
        # saving

        return error_message